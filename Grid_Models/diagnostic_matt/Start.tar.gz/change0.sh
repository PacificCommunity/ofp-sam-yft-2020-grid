#!/bin/sh
cp Start.tar.gz Start0.tar.gz
