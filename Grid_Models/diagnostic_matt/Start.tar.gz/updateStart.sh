#!/bin/bash

tar -czf Start.tar.gz --exclude '*.tar.gz' *
