#!/bin/sh
cp End.tar.gz Start"$1".tar.gz
mv End.tar.gz Start.tar.gz
